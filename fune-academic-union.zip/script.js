let users = JSON.parse(localStorage.getItem("users")) || [];
let isAdminLoggedIn = false;

function saveUsers() {
  localStorage.setItem("users", JSON.stringify(users));
}

function registerUser() {
  const name = document.getElementById("regName").value.trim();
  const password = document.getElementById("regPassword").value;

  if (name === "" || password === "") {
    alert("Please fill in both fields.");
    return;
  }

  if (users.some(u => u.name === name)) {
    alert("User already exists. Please login.");
    return;
  }

  users.push({ name, password });
  saveUsers();
  alert("Registration successful!");
  document.getElementById("regName").value = "";
  document.getElementById("regPassword").value = "";
  displayUsers();
}

function loginUser() {
  const name = document.getElementById("loginName").value.trim();
  const password = document.getElementById("loginPassword").value;

  if (name === "admin" && password === "admin123") {
    alert("Welcome, Admin!");
    isAdminLoggedIn = true;
    displayUsers();
    return;
  }

  const user = users.find(u => u.name === name && u.password === password);
  if (user) {
    alert(`Welcome, ${name}! You are now logged in.`);
  } else {
    alert("Invalid credentials. Please try again.");
  }

  document.getElementById("loginName").value = "";
  document.getElementById("loginPassword").value = "";
}

function displayUsers() {
  const userDisplay = document.getElementById("userDisplay");
  const adminSection = document.querySelector(".admin-view");

  if (!isAdminLoggedIn) {
    adminSection.style.display = "none";
    return;
  }

  adminSection.style.display = "block";
  userDisplay.innerHTML = "";

  users.forEach((user, index) => {
    const div = document.createElement("div");
    div.className = "user";
    div.innerHTML = `<strong>${index + 1}. ${user.name}</strong>`;
    userDisplay.appendChild(div);
  });
}

function showLogin() {
  document.getElementById("registerForm").style.display = "none";
  document.getElementById("loginForm").style.display = "block";
}

function showRegister() {
  document.getElementById("loginForm").style.display = "none";
  document.getElementById("registerForm").style.display = "block";
}

displayUsers();
